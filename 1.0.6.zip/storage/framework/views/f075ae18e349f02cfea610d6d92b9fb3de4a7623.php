

<?php $__env->startSection('title', 'Constancias de Viaje'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <a href="<?php echo e(Route('travelCertificates')); ?>" class="btn btn-secondary mr-2">Volver</a>
        <h1 class="col-7">Constancia de Viaje N°<strong><?php echo e($travelCertificate->number); ?></strong></h1>
        <?php if($travelCertificate->invoiced == 'NO'): ?>
        <button class="btn btn-danger col-2 mr-2" data-toggle="modal" data-target="#storeModal">Agregar Nuevo Item</button>
        <button class="btn btn-success col-2" data-toggle="modal" data-target="#updateModal<?php echo e($travelCertificate->id); ?>">Actualizar Constancia</button>
        <?php else: ?>
        <a href="<?php echo e(Route('travelCertificatePdf', $travelCertificate->id)); ?>" class="btn btn-info col-4">Generar PDF</a>
        <strong class="text-danger">La constancia ha sido agregada a la factura <a href="<?php echo e(Route('showInvoice', $travelCertificate->invoice->id)); ?>"><?php echo e($travelCertificate->invoice->id); ?></a>, no se pueden realizar modificaciones.</strong>
        <?php endif; ?>
    </div>
    <?php echo $__env->make('travelItem.modals.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('travelCertificate.modals.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h4>Detalles</h4>
    <table class="table table-bordered text-center">
        <thead class="bg-danger">
            <tr>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Chofer</th>
                <th>Pago al Chofer</th>
                <th>Precio (Sin IVA)</th>
                <th>IVA</th>
                <th>Destino</th>
                <th>Precio Total (Con IVA)</th>
                <th>Facturado</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($travelCertificate->date); ?></td>
                <td><?php echo e($travelCertificate->client->name); ?></td>
                <td><?php echo e($travelCertificate->driver->name); ?></td>
                <td><?php echo e($travelCertificate->driverPayment); ?></td>
                <td><?php echo e($travelCertificate->total); ?></td>
                <td><?php echo e($travelCertificate->iva); ?></td>
                <td><?php echo e($travelCertificate->destiny); ?></td>
                <td><?php echo e($travelCertificate->total + $travelCertificate->iva); ?></td>
                <td><?php echo e($travelCertificate->invoiced); ?></td>
            </tr>
        </tbody>
    </table>
    <h4>Items de Viaje</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Tipo</th>
                <th>Precio Total</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $travelCertificate->travelItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travelItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($travelItem->type); ?></td>
                    <td><?php echo e($travelItem->price); ?></td>
                    <?php if($travelCertificate->invoiced == 'NO'): ?>
                        <td>
                            <button class="btn btn-danger" data-toggle="modal" data-target="#deleteItemModal<?php echo e($travelItem->id); ?>">Eliminar</button>
                        </td>
                    <?php else: ?>
                        <td>
                            <strong class="text-danger">¡No se pueden realizar cambios!</strong>
                        </td>
                    <?php endif; ?>
                </tr>
                <?php echo $__env->make('travelItem.modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/travelCertificate/show.blade.php ENDPATH**/ ?>