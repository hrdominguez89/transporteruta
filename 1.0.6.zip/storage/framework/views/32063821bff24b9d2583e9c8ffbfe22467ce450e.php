

<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <h1 class="col-7">Clientes</h1>
        <a href="<?php echo e(Route('generateDebtorsPdf')); ?>" class="btn btn-info col-2 mr-2">Reporte Deudores</a>
        <button class="btn btn-danger col-2" data-toggle="modal" data-target="#storeModal">Agregar Cliente</button>
    </div>
    <?php echo $__env->make('client.modals.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Nombre</th>
                <th>DNI/CUIT</th>
                <th>Saldo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($client->name); ?></td>
                    <td><?php echo e($client->dni); ?></td>
                    <?php if($client->balance > 0): ?>
                    <td class="bg-danger"><?php echo e($client->balance); ?></td>
                    <?php else: ?>
                    <td><?php echo e($client->balance); ?></td>
                    <?php endif; ?>
                    <td>
                        <a href="<?php echo e(Route('showClient', $client->id)); ?>" class="btn btn-info">Ver</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/client/index.blade.php ENDPATH**/ ?>