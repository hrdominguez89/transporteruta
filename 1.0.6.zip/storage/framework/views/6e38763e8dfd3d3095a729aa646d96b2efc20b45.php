

<?php $__env->startSection('title', 'Constancias de Viaje'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <h1 class="col-9">Constancias de Viaje</h1>
        <button class="btn btn-danger col-2" data-toggle="modal" data-target="#storeModal">Agregar Constancia</button>
    </div>
    <?php echo $__env->make('travelCertificate.modals.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Cliente</th>
                <th>Chofer</th>
                <th>Facturada</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $travelCertificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travelCertificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($travelCertificate->number); ?></td>
                    <td><?php echo e($travelCertificate->client->name); ?></td>
                    <td><?php echo e($travelCertificate->driver->name); ?></td>
                    <td><?php echo e($travelCertificate->invoiced); ?></td>
                    <td>
                        <a href="<?php echo e(Route('showTravelCertificate', $travelCertificate->id)); ?>" class="btn btn-info">Ver</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/travelCertificate/index.blade.php ENDPATH**/ ?>