<div class="modal fade" id="addInvoiceModal<?php echo e($credit->id); ?>" tabindex="-1" aria-labelledby="storeModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger">
        <h5 class="modal-title">Agregar Factura</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(Route('addInvoiceToCredit', $credit->id)); ?>" class="form-group" method="POST">
            <?php echo csrf_field(); ?>
            <label for="total">Saldo a Descontar:</label>
            <input type="number" name="total" class="form-control mb-2" required>
            <label for="invoiceId">Facturas:</label>
            <select name="invoiceId" class="form-control mb-2" required>
                <option value="">---- Seleccione una opcion ----</option>
                <?php $__currentLoopData = $credit->client->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($invoice->id); ?>"><?php echo e($invoice->number); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Generar</button>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/credit/modals/addInvoice.blade.php ENDPATH**/ ?>