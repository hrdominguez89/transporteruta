

<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <a href="<?php echo e(Route('clients')); ?>" class="btn btn-secondary mr-2">Volver</a>
        <h1 class="col-9">Cliente: <strong><?php echo e($client->name); ?></strong></h1>
        <button class="btn btn-success col-2" data-toggle="modal" data-target="#updateModal<?php echo e($client->id); ?>">Actualizar Cliente</button>
        <?php echo $__env->make('client.modals.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h4>Datos del Cliente</h4>
    <table class="table table-bordered text-center">
        <thead class="bg-danger">
            <tr>
                <th>DNI/CUIT</th>
                <th>Direccion</th>
                <th>Ciudad</th>
                <th>Telefono</th>
                <th>IVA Tipo</th>
                <th>Saldo Deudor</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($client->dni); ?></td>
                <td><?php echo e($client->address); ?></td>
                <td><?php echo e($client->city); ?></td>
                <td><?php echo e($client->phone); ?></td>
                <td><?php echo e($client->ivaType); ?></td>
                <td><?php echo e($client->balance); ?></td>
            </tr>
        </tbody>
    </table>
    <h4>Observaciones:</h4>
    <p><?php echo e($client->observations); ?></p>
    <br>
    <h4>Facturas Pendientes de Pagar</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Total con IVA</th>
                <th>Balance</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $client->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($invoice->paid == 'NO' and $invoice->invoiced == 'SI'): ?>
                <tr>
                    <td><?php echo e($invoice->number); ?></td>
                    <td><?php echo e($invoice->totalWithIva); ?></td>
                    <td><?php echo e($invoice->balance); ?></td>
                    <td>
                        <a href="<?php echo e(Route('showInvoice', $invoice->id)); ?>" class="btn btn-info">Ver</a>
                    </td>
                </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <h4>Facturas Abiertas</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Total con IVA</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $client->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($invoice->invoiced == 'NO'): ?>
                <tr>
                    <td><?php echo e($invoice->number); ?></td>
                    <td><?php echo e($invoice->totalWithIva); ?></td>
                    <td>
                        <a href="<?php echo e(Route('showInvoice', $invoice->id)); ?>" class="btn btn-info">Ver</a>
                    </td>
                </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <h4>Facturas Pagadas</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Total con IVA</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $client->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($invoice->paid == 'SI'): ?>
                <tr>
                    <td><?php echo e($invoice->number); ?></td>
                    <td><?php echo e($invoice->totalWithIva); ?></td>
                    <td>
                        <a href="<?php echo e(Route('showInvoice', $invoice->id)); ?>" class="btn btn-info">Ver</a>
                    </td>
                </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/client/show.blade.php ENDPATH**/ ?>