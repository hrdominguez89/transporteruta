<div class="modal fade" id="cancelModal<?php echo e($travelCertificate->id); ?>" tabindex="-1" aria-labelledby="cancelModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger">
        <h5 class="modal-title">¿Desea anular el pago al chofer?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(Route('cancelPay', $travelCertificate->id)); ?>" class="form-group">
            <p>Se anulara el pago a <strong><?php echo e($travelCertificate->driver->name); ?></strong> por un total de <strong><?php echo e($travelCertificate->driverPayment); ?></strong><br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-warning">Anular</button>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/driver/modals/cancel.blade.php ENDPATH**/ ?>