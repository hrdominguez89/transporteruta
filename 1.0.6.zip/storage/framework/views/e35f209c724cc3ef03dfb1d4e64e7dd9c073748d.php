<div class="modal fade" id="generateModal" tabindex="-1" aria-labelledby="storeModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger">
        <h5 class="modal-title">Generar Nota de Credito</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(Route('generateCredit')); ?>" class="form-group" method="POST">
            <?php echo csrf_field(); ?>
            <label for="number">Numero:</label>
            <input type="number" name="number" class="form-control mb-2" required>
            <label for="date">Fecha:</label>
            <input type="date" name="date" class="form-control mb-2" required>
            <label for="clientId">Cliente:</label>
            <select name="clientId" class="form-control mb-2" required>
                <option value="">---- Seleccione una opcion ----</option>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Generar</button>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/credit/modals/generate.blade.php ENDPATH**/ ?>