<div class="modal fade" id="cancelModal<?php echo e($invoice->id); ?>" tabindex="-1" aria-labelledby="cancelModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger">
        <h5 class="modal-title">¿Desea anular la factura?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(Route('cancelInvoice', $invoice->id)); ?>" class="form-group">
            <p>Se anulara la factura <strong><?php echo e($invoice->number); ?></strong> del cliente <strong><?php echo e($invoice->client->name); ?></strong><br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-warning">Anular</button>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/invoice/modals/cancel.blade.php ENDPATH**/ ?>