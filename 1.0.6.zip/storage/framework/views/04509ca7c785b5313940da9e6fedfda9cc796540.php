

<?php $__env->startSection('title', 'Facturas'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <h1 class="col-10">Facturas</h1>
        <button class="btn btn-danger" data-toggle="modal" data-target="#generateModal">Generar Factura</button>
    </div>
    <?php echo $__env->make('invoice.modals.generate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Cliente</th>
                <th>Total (Con IVA)</th>
                <th>Balance</th>
                <th>Facturado</th>
                <th>Pagada</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($invoice->number); ?></td>
                    <td><?php echo e($invoice->client->name); ?></td>
                    <td><?php echo e($invoice->totalWithIva); ?></td>
                    <td><?php echo e($invoice->balance); ?></td>
                    <td><?php echo e($invoice->invoiced); ?></td>
                    <td><?php echo e($invoice->paid); ?></td>
                    <td>
                        <a href="<?php echo e(Route('showInvoice', $invoice->id)); ?>" class="btn btn-info">Ver</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/invoice/index.blade.php ENDPATH**/ ?>