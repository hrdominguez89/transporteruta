

<?php $__env->startSection('title', 'Choferes'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <h1 class="col-9">Choferes</h1>
        <button class="btn btn-danger col-2" data-toggle="modal" data-target="#storeModal">Agregar Chofer</button>
    </div>
    <?php echo $__env->make('driver.modals.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Nombre</th>
                <th>DNI/CUIT</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($driver->name); ?></td>
                    <td><?php echo e($driver->dni); ?></td>
                    <td>
                        <a href="<?php echo e(Route('showDriver', $driver->id)); ?>" class="btn btn-info">Ver</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/driver/index.blade.php ENDPATH**/ ?>