

<?php $__env->startSection('title', 'Choferes'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <a href="<?php echo e(Route('drivers')); ?>" class="btn btn-secondary mr-2">Volver</a>
        <h1 class="col-9">Chofer: <strong><?php echo e($driver->name); ?></strong></h1>
        <button class="btn btn-success col-2" data-toggle="modal" data-target="#updateModal<?php echo e($driver->id); ?>">Actualizar Chofer</button>
        <?php echo $__env->make('driver.modals.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h4>Datos del Chofer</h4>
    <table class="table table-bordered text-center">
        <thead class="bg-danger">
            <tr>
                <th>DNI/CUIT</th>
                <th>Direccion</th>
                <th>Ciudad</th>
                <th>Telefono</th>
                <th>Tipo</th>
                <th>Vehiculo</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($driver->dni); ?></td>
                <td><?php echo e($driver->address); ?></td>
                <td><?php echo e($driver->city); ?></td>
                <td><?php echo e($driver->phone); ?></td>
                <td><?php echo e($driver->type); ?></td>
                <td><?php echo e($driver->vehicle->name); ?></td>
            </tr>
        </tbody>
    </table>
    <br>
    <h4>Liquidaciones Pendientes</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Fecha</th>
                <th>Pago a la Agencia</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $driver->driverSettlements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driverSettlement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($driverSettlement->liquidated =='NO'): ?>
                <tr>
                    <td><?php echo e($driverSettlement->number); ?></td>
                    <td><?php echo e($driverSettlement->date); ?></td>
                    <td><?php echo e($driverSettlement->total); ?></td>
                    <td>
                        <a href="<?php echo e(Route('showDriverSettlement', $driverSettlement->id)); ?>" class="btn btn-info">Ver</a>
                    </td>
                </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <h4>Liquidaciones Realizadas</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Fecha</th>
                <th>Pago a la Agencia</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $driver->driverSettlements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driverSettlement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($driverSettlement->liquidated =='SI'): ?>
                <tr>
                    <td><?php echo e($driverSettlement->number); ?></td>
                    <td><?php echo e($driverSettlement->date); ?></td>
                    <td><?php echo e($driverSettlement->total); ?></td>
                    <td>
                        <a href="<?php echo e(Route('showDriverSettlement', $driverSettlement->id)); ?>" class="btn btn-info">Ver</a>
                    </td>
                </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/driver/show.blade.php ENDPATH**/ ?>