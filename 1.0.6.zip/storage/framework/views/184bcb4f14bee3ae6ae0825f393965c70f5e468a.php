

<?php $__env->startSection('title', 'Liquidaciones de Choferes'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <a href="<?php echo e(Route('driverSettlements')); ?>" class="btn btn-secondary mr-2">Volver</a>
        <h1 class="col-8">Liquidacion N°<strong><?php echo e($driverSettlement->number); ?></strong></h1>
        <?php if($driverSettlement->liquidated == 'NO'): ?>
            <button class="btn btn-primary col-3" data-toggle="modal" data-target="#liquidatedModal<?php echo e($driverSettlement->id); ?>">Liquidar</button>
        <?php else: ?>
        <button class="btn btn-danger mr-2" data-toggle="modal" data-target="#cancelModal<?php echo e($driverSettlement->id); ?>">Anular Liquidacion</button>
        <a href="<?php echo e(Route('driverSettlementPdf', $driverSettlement->id)); ?>" class="btn btn-info">Emitir Comprobante</a>
        <?php endif; ?>
    </div>
    <?php echo $__env->make('driverSettlement.modals.liquidated', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('driverSettlement.modals.cancel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table class="table table-bordered text-center">
        <thead class="bg-danger">
            <tr>
                <th>Fecha</th>
                <th>Chofer</th>
                <th>Total</th>
                <th>Liquidado</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($driverSettlement->date); ?></td>
                <td>
                    <a href="<?php echo e(Route('showDriver', $driverSettlement->driver->id)); ?>"><?php echo e($driverSettlement->driver->name); ?></a>
                </td>
                <td><?php echo e($driverSettlement->total); ?></td>
                <td><?php echo e($driverSettlement->liquidated); ?></td>
            </tr>
        </tbody>
    </table>
    <br>
    <h4>Constancias de Viaje Agregadas</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Cliente</th>
                <th>Tarifa Chofer</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $driverSettlement->travelCertificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travelCertificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(Route('showTravelCertificate', $travelCertificate->id)); ?>"><?php echo e($travelCertificate->id); ?></a>
                    </td>
                    <td><?php echo e($travelCertificate->client->name); ?></td>
                    <td><?php echo e($travelCertificate->total - $travelCertificate->driverPayment); ?></td>
                    <td>
                        <?php if($driverSettlement->liquidated == 'NO'): ?>
                            <form action="<?php echo e(Route('removeFromDriverSettlement', $travelCertificate->id)); ?>" method="POST"    >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="driverSettlementId" value="<?php echo e($driverSettlement->id); ?>">
                                <button type="submit" class="btn btn-warning">Quitar de la Liquidacion</button>
                            </form>
                        <?php else: ?>
                            <strong class="text-danger">¡No se pueden realizar cambios!</strong>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <?php if($driverSettlement->liquidated == 'NO'): ?>
    <h4>Constancias de Viaje del Chofer sin Liquidar</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Cliente</th>
                <th>Tarifa del Chofer</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $driverSettlement->driver->travelCertificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travelCertificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($travelCertificate->date >= $driverSettlement->dateFrom and $travelCertificate->date <= $driverSettlement->dateTo): ?>
                <?php if($travelCertificate->driverSettlementId != $driverSettlement->id and $travelCertificate->isPaidToDriver == 'NO'): ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(Route('showTravelCertificate', $travelCertificate->id)); ?>"><?php echo e($travelCertificate->id); ?></a>
                        </td>
                        <td><?php echo e($travelCertificate->driver->name); ?></td>
                        <td><?php echo e($travelCertificate->total - $travelCertificate->driverPayment); ?></td>
                        <td>
                            <form action="<?php echo e(Route('addToDriverSettlement', $travelCertificate->id)); ?>" method="POST"    >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="driverSettlementId" value="<?php echo e($driverSettlement->id); ?>">
                                <button type="submit" class="btn btn-success">Agregar a la Liquidacion</button>
                            </form>
                        </td>
                    </tr>
                <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/driverSettlement/show.blade.php ENDPATH**/ ?>