

<?php $__env->startSection('title', 'Recibos'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <h1 class="col-10">Recibos</h1>
        <button class="btn btn-danger" data-toggle="modal" data-target="#generateModal">Generar Recibo</button>
    </div>
    <?php echo $__env->make('receipt.modals.generate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Cliente</th>
                <th>Total</th>
                <th>Pagado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($receipt->number); ?></td>
                    <td><?php echo e($receipt->client->name); ?></td>
                    <td><?php echo e($receipt->total); ?></td>
                    <td><?php echo e($receipt->paid); ?></td>
                    <td>
                        <a href="<?php echo e(Route('showReceipt', $receipt->id)); ?>" class="btn btn-info">Ver</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/receipt/index.blade.php ENDPATH**/ ?>