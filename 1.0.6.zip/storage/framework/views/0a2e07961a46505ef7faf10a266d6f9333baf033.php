

<?php $__env->startSection('title', 'Notas de Credito'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
    <a href="<?php echo e(Route('credits')); ?>" class="btn btn-secondary">Volver</a>
    <h1 class="col-9">Nota de Credito N°<strong><?php echo e($credit->number); ?></strong></h1>
    <?php if($credit->invoiceId == 0): ?>
        <button class="btn btn-primary" data-toggle="modal" data-target="#addInvoiceModal<?php echo e($credit->id); ?>">Agregar Factura</button>
    <?php else: ?>
        <button class="btn btn-danger" data-toggle="modal" data-target="#removeInvoiceModal<?php echo e($credit->id); ?>">Quitar Factura</button>
    <?php endif; ?>
    </div>
    <?php echo $__env->make('credit.modals.addInvoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('credit.modals.removeInvoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Total</th>
                <th>Factura</th>
            </tr>
        </thead>
        <tbody>
                <tr>
                    <td><?php echo e($credit->number); ?></td>
                    <td><?php echo e($credit->date); ?></td>
                    <td>
                        <a href="<?php echo e(Route('showClient', $credit->client->id)); ?>"><?php echo e($credit->client->name); ?></a>
                    </td>
                    <td><?php echo e($credit->total); ?></td>
                    <td>
                        <?php if($credit->invoiceId != 0): ?>
                            <a href="<?php echo e(Route('showInvoice', $credit->invoiceId)); ?>"><?php echo e($credit->invoice->number); ?></a>
                        <?php else: ?>
                            <span class="text-danger">No Agregada</span>
                        </td>
                        <?php endif; ?>
                </tr>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/credit/show.blade.php ENDPATH**/ ?>