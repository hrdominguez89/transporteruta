

<?php $__env->startSection('title', 'Recibos'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <a href="<?php echo e(Route('receipts')); ?>" class="btn btn-secondary">Volver</a>
        <h1 class="col-7">Recibo N°<strong><?php echo e($receipt->id); ?></strong></h1>
        <?php if($receipt->paid == 'NO'): ?>
            <button class="btn btn-warning col-4" data-toggle="modal" data-target="#paidModal<?php echo e($receipt->id); ?>">Marcar como Pagado</button>
        <?php else: ?>
            <button class="btn btn-danger col-2 mr-2" data-toggle="modal" data-target="#cancelModal<?php echo e($receipt->id); ?>">Anular Pago</button>
            <a href="<?php echo e(Route('receiptPdf', $receipt->id)); ?>" class="btn btn-info col-2">Generar PDF</a>
        <?php endif; ?>
    </div>
    <?php if($receipt->paid == 'SI'): ?> 
       <h5 class="text-danger">El recibo se marco como pagado y se desconto el saldo de la cuenta corriente</h5> 
    <?php endif; ?>
    <?php echo $__env->make('receipt.modals.paid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('receipt.modals.cancel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table class="table table-bordered text-center">
        <thead class="bg-danger">
            <tr>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Pagado</th>
                <th>Retenciones</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($receipt->date); ?></td>
                <td>
                    <a href="<?php echo e(Route('showClient', $receipt->client->id)); ?>"><?php echo e($receipt->client->name); ?></a>
                </td>
                <td><?php echo e($receipt->paid); ?></td>
                <td><?php echo e($receipt->taxTotal); ?></td>
                <td><?php echo e($receipt->total); ?></td>
            </tr>
        </tbody>
    </table>
    <br>
    <h4>Facturas Agregadas</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Cliente</th>
                <th>Precio (Con IVA)</th>
                <th>Balance</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $receipt->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(Route('showInvoice', $invoice->id)); ?>"><?php echo e($invoice->number); ?></a>
                    </td>
                    <td><?php echo e($invoice->client->name); ?></td>
                    <td><?php echo e($invoice->totalWithIva); ?></td>
                    <td><?php echo e($invoice->balance); ?></td>
                    <td>
                        <?php if($receipt->paid == 'NO'): ?>
                            <form action="<?php echo e(Route('removeFromReceipt', $invoice->id)); ?>" method="POST"    >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="receiptId" value="<?php echo e($receipt->id); ?>">
                                <button type="submit" class="btn btn-warning">Quitar del Recibo</button>
                            </form>
                        <?php else: ?>
                            <strong class="text-danger">¡No se pueden realizar cambios!</strong>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <?php if($receipt->paid == 'NO'): ?>
    <h4>Facturas del Cliente sin Pagar</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Cliente</th>
                <th>Precio (Con IVA)</th>
                <th>Balance</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $receipt->client->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($invoice->paid == 'NO' and $invoice->invoiced == 'SI'): ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(Route('showInvoice', $invoice->id)); ?>"><?php echo e($invoice->number); ?></a>
                        </td>
                        <td><?php echo e($invoice->client->name); ?></td>
                        <td><?php echo e($invoice->totalWithIva); ?></td>
                        <td><?php echo e($invoice->balance); ?></td>
                        <td>
                            <button class="btn btn-success" data-toggle="modal" data-target="#addInvoiceModal<?php echo e($invoice->id); ?><?php echo e($receipt->id); ?>">Agregar al Recibo</button>
                        </td>
                    </tr>
                <?php endif; ?>
                <?php echo $__env->make('receipt.modals.addInvoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/receipt/show.blade.php ENDPATH**/ ?>