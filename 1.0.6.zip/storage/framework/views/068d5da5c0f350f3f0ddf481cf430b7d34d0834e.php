<div class="modal fade" id="updateModal<?php echo e($client->id); ?>" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger">
        <h5 class="modal-title">Editar Cliente</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(Route('updateClient', $client->id)); ?>" class="form-group" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label for="name">Nombre:</label>
            <input type="text" name="name" class="form-control mb-2" placeholder="Ingrese el nombre..." value="<?php echo e($client->name); ?>" required>
            <label for="dni">DNI/CUIT:</label>
            <input type="text" name="dni" class="form-control mb-2" placeholder="Ingrese el DNI/CUIT..." value="<?php echo e($client->dni); ?>" required>
            <label for="address">Direccion:</label>
            <input type="text" name="address" class="form-control mb-2" placeholder="Ingrese la direccion..." value="<?php echo e($client->address); ?>" required>
            <label for="city">Ciudad:</label>
            <input type="text" name="city" class="form-control mb-2" placeholder="Ingrese la ciudad..." value="<?php echo e($client->city); ?>" required>
            <label for="phpne">Telefono:</label>
            <input type="text" name="phone" class="form-control mb-2" placeholder="Ingrese el telefono..." value="<?php echo e($client->phone); ?>" required>
            <label for="ivaType">IVA Tipo:</label>
            <select name="ivaType" class="form-control mb-2" required>
                <option  value="<?php echo e($client->ivaType); ?>"><?php echo e($client->ivaType); ?></option>
                <option value="CONSUMIDOR FINAL">Consumidor Final</option>
                <option value="RESPONSABLE INSCRIPTO">Responsable Inscripto</option>
                <option value="EXENTO">Exento</option>
            </select>
            <label for="observations">Observaciones (Opcional):</label>
            <input type="text" name="observations" class="form-control mb-2" placeholder="Ingrese las observaciones..." value="<?php echo e($client->observations); ?>">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-success">Actualizar</button>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/client/modals/update.blade.php ENDPATH**/ ?>