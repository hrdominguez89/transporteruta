

<?php $__env->startSection('title', 'Facturas'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <a href="<?php echo e(Route('invoices')); ?>" class="btn btn-secondary">Volver</a>
        <h1 class="col-7">Factura N°<strong><?php echo e($invoice->number); ?></strong></h1>
        <?php if($invoice->invoiced == 'SI' and $invoice->paid == 'NO'): ?>
            <button class="btn btn-danger col-2 mr-2" data-toggle="modal" data-target="#cancelModal<?php echo e($invoice->id); ?>">Anular Factura</button>
            <a href="<?php echo e(Route('invoicePdf', $invoice->id)); ?>" class="btn btn-info col-2">Generar PDF</a>
        <?php elseif($invoice->invoiced == 'NO'): ?>
            <button class="btn btn-primary col-4" data-toggle="modal" data-target="#invoicedModal<?php echo e($invoice->id); ?>">Facturar</button>
        <?php endif; ?>
        <?php if($invoice->paid == 'SI'): ?> 
        <a href="<?php echo e(Route('invoicePdf', $invoice->id)); ?>" class="btn btn-info col-4">Generar PDF</a>
        <br>
        <h5 class="text-danger">La factura se marco como pagada y se desconto el saldo de la cuenta corriente</h5>
        <?php endif; ?>
    </div>
    <?php echo $__env->make('invoice.modals.invoiced', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('invoice.modals.cancel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table class="table table-bordered text-center">
        <thead class="bg-danger">
            <tr>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Total (Sin IVA)</th>
                <th>IVA</th>
                <th>Balance</th>
                <th>Facturado</th>
                <th>Total (Con IVA)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($invoice->date); ?></td>
                <td>
                    <a href="<?php echo e(Route('showClient', $invoice->client->id)); ?>"><?php echo e($invoice->client->name); ?></a>
                </td>
                <td><?php echo e($invoice->total); ?></td>
                <td><?php echo e($invoice->iva); ?></td>
                <td><?php echo e($invoice->balance); ?></td>
                <td><?php echo e($invoice->invoiced); ?></td>
                <td><?php echo e(($invoice->total + $invoice->iva)); ?></td>
            </tr>
        </tbody>
    </table>
    <br>
    <h4>Notas de Credito</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Fecha</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $invoice->credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(Route('showCredit', $credit->id)); ?>"><?php echo e($credit->number); ?></a>
                    </td>
                    <td><?php echo e($credit->date); ?></td>
                    <td><?php echo e($credit->total); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <h4>Constancias de Viaje Agregadas</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Chofer</th>
                <th>Precio (Sin IVA)</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $invoice->travelCertificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travelCertificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(Route('showTravelCertificate', $travelCertificate->id)); ?>"><?php echo e($travelCertificate->number); ?></a>
                    </td>
                    <td><?php echo e($travelCertificate->driver->name); ?></td>
                    <td><?php echo e($travelCertificate->total); ?></td>
                    <td>
                        <?php if($invoice->invoiced == 'NO'): ?>
                            <form action="<?php echo e(Route('removeFromInvoice', $travelCertificate->id)); ?>" method="POST"    >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="invoiceId" value="<?php echo e($invoice->id); ?>">
                                <button type="submit" class="btn btn-warning">Quitar de la Factura</button>
                            </form>
                        <?php else: ?>
                            <strong class="text-danger">¡No se pueden realizar cambios!</strong>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <?php if($invoice->invoiced == 'NO'): ?>
    <h4>Constancias de Viaje del Cliente sin Liquidar</h4>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Numero</th>
                <th>Chofer</th>
                <th>Precio (Sin IVA)</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $invoice->client->travelCertificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travelCertificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($travelCertificate->invoiceId != $invoice->id and $travelCertificate->invoiced == 'NO'): ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(Route('showTravelCertificate', $travelCertificate->id)); ?>"><?php echo e($travelCertificate->number); ?></a>
                        </td>
                        <td><?php echo e($travelCertificate->driver->name); ?></td>
                        <td><?php echo e($travelCertificate->total); ?></td>
                        <td>
                            <form action="<?php echo e(Route('addToInvoice', $travelCertificate->id)); ?>" method="POST"    >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="invoiceId" value="<?php echo e($invoice->id); ?>">
                                <button type="submit" class="btn btn-success">Agregar a la Factura</button>
                            </form>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/invoice/show.blade.php ENDPATH**/ ?>