<div class="modal fade" id="paidModal<?php echo e($invoice->id); ?>" tabindex="-1" aria-labelledby="paidModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger">
        <h5 class="modal-title">¿Desea marcar como pagada la factura?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(Route('paidInvoice', $invoice->id)); ?>" class="form-group">
            <p>Se registrara que el cliente: <strong><?php echo e($invoice->client->name); ?></strong> ha pagado<p>
            <p><strong class="text-danger">¡Esta accion es IRREVERSIBLE!</strong></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-warning">Confirmar</button>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/invoice/modals/paid.blade.php ENDPATH**/ ?>