<div class="modal fade" id="deleteModal<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="deleteItemModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-warning">
        <h5 class="modal-title">Eliminar Usuario</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(Route('deleteUser', $user->id)); ?>" class="form-group" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <p>Se eliminara el usuario <?php echo e($user->name); ?>.<br>
            <strong class="text-warning">¡ESTA ACCION ES IRREVERSIBLE!</strong></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-warning">Eliminar</button>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/user/modals/delete.blade.php ENDPATH**/ ?>