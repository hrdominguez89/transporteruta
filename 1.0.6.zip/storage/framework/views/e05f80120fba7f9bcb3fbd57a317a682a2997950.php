<div class="modal fade" id="addInvoiceModal<?php echo e($invoice->id); ?><?php echo e($receipt->id); ?>" tabindex="-1" aria-labelledby="storeModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger">
        <h5 class="modal-title">Agregar Factura</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(Route('addToReceipt', $invoice->id)); ?>" class="form-group" method="POST">
            <?php echo csrf_field(); ?>
            <p>Saldo Restante: <strong><?php echo e($invoice->balance); ?></strong></p>
            <input type="hidden" name="receiptId" value="<?php echo e($receipt->id); ?>">
            <label for="balanceToPay">Saldo a Pagar:</label>
            <input type="number" name="balanceToPay" class="form-control mb-2" required>
            <label for="paymentMethodId">Medio de Pago:</label>
            <select name="paymentMethodId" class="form-control mb-2" required>
                <option value="">---- Seleccione una opcion ----</option>
                <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($paymentMethod->id); ?>"><?php echo e($paymentMethod->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="taxId">Impuesto:</label>
            <select name="taxId" class="form-control mb-2" required>
                <option value="">---- Seleccione una opcion ----</option>
                <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($tax->id); ?>"><?php echo e($tax->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="taxAmount">Monto de Impuesto:</label>
            <input type="number" name="taxAmount" class="form-control mb-2" required>

    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-success">Agregar</button>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/receipt/modals/addInvoice.blade.php ENDPATH**/ ?>