

<?php $__env->startSection('title', 'Impuestos'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <h1 class="col-10">Impuestos</h1>
        <button class="btn btn-danger" data-toggle="modal" data-target="#storeModal">Agregar Impuesto</button>
    </div>
    <?php echo $__env->make('tax.modals.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Nombre</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tax->name); ?></td>
                    <td>
                        <button class="btn btn-success" data-toggle="modal" data-target="#updateModal<?php echo e($tax->id); ?>">Editar</button>
                    </td>
                </tr>
                <?php echo $__env->make('tax.modals.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/tax/index.blade.php ENDPATH**/ ?>