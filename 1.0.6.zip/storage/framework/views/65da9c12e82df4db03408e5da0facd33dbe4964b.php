

<?php $__env->startSection('title', 'Vehiculos'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <h1 class="col-10">Vehiculos</h1>
        <button class="btn btn-danger" data-toggle="modal" data-target="#storeModal">Agregar Vehiculo</button>
    </div>
    <?php echo $__env->make('vehicle.modals.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered text-center data-table">
        <thead class="bg-danger">
            <tr>
                <th>Nombre</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($vehicle->name); ?></td>
                    <td>
                        <button class="btn btn-success" data-toggle="modal" data-target="#updateModal<?php echo e($vehicle->id); ?>">Editar</button>
                    </td>
                </tr>
                <?php echo $__env->make('vehicle.modals.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/vehicle/index.blade.php ENDPATH**/ ?>