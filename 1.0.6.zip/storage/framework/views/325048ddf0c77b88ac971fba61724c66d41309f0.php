<div class="modal fade" id="updateModal<?php echo e($driver->id); ?>" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger">
        <h5 class="modal-title">Editar Chofer</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(Route('updateDriver', $driver->id)); ?>" class="form-group" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label for="name">Nombre:</label>
            <input type="text" name="name" class="form-control mb-2" placeholder="Ingrese el nombre..." value="<?php echo e($driver->name); ?>" required>
            <label for="dni">DNI/CUIT:</label>
            <input type="text" name="dni" class="form-control mb-2" placeholder="Ingrese el DNI/CUIT..." value="<?php echo e($driver->dni); ?>" required>
            <label for="address">Direccion:</label>
            <input type="text" name="address" class="form-control mb-2" placeholder="Ingrese la direccion..." value="<?php echo e($driver->address); ?>" required>
            <label for="city">Ciudad:</label>
            <input type="text" name="city" class="form-control mb-2" placeholder="Ingrese la ciudad..." value="<?php echo e($driver->city); ?>" required>
            <label for="phone">Telefono:</label>
            <input type="text" name="phone" class="form-control mb-2" placeholder="Ingrese el telefono..." value="<?php echo e($driver->phone); ?>" required>
            <label for="percent">Porcentaje de la Agencia:</label>
            <input type="number" name="percent" class="form-control mb-2" placeholder="Ingrese el porcentaje de la agencia..." value="<?php echo e($driver->percent); ?>" required>            
            <label for="type">Tipo:</label>
            <select name="type" class="form-control mb-2" required>
                <option  value="<?php echo e($driver->type); ?>"><?php echo e($driver->type); ?></option>
                <option value="PROPIO">Propio</option>
                <option value="TERCERO">Tercero</option>
            </select>
            <label for="vehicleId">Vehiculo:</label>
            <select name="vehicleId" class="form-control mb-2">
                <option value="<?php echo e($driver->vehicleId); ?>"><?php echo e($driver->vehicle->name); ?></option>
                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($vehicle->id); ?>"><?php echo e($vehicle->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-success">Actualizar</button>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/driver/modals/update.blade.php ENDPATH**/ ?>