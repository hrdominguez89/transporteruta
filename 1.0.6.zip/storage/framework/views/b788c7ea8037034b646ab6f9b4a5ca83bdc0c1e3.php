

<?php $__env->startSection('title', 'Panel de Control'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="col-10">¡Bienvenido <?php echo e(Auth::user()->name); ?>!</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-12">
    <div class="row">
        <div class="col-3">
            <div class="col-12">
                    <div class="col-12 bg-primary text-center p-5">
                        <h2>Clientes Registrados</h2>
                        <h1><b><?php echo e($clientsCount); ?></b></h1>
                        <a href="<?php echo e(Route('clients')); ?>" class="btn btn-secondary">Ir a Clientes</a>                    
                    </div>
                </div>
                <br>
                <div class="col-12">
                    <div class="col-12 bg-info text-center p-5">
                        <h2>Choferes Registrados</h2>
                        <h1><b><?php echo e($driversCount); ?></b></h1>      
                        <a href="<?php echo e(Route('drivers')); ?>" class="btn btn-warning">Ir a Choferes</a>                
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="col-12">
                    <div class="col-12 bg-light text-center p-5">
                        <h2>Facturas Abiertas</h2>
                        <h1><b><?php echo e($invoicesCount); ?></b></h1>
                        <a href="<?php echo e(Route('invoices')); ?>" class="btn btn-success">Ir a Facturas</a>                    
                    </div>
                </div>
                <br>
                <div class="col-12">
                    <div class="col-12 bg-dark text-center p-5">
                        <h2>Recibos Pendientes</h2>
                        <h1><b><?php echo e($receiptsCount); ?></b></h1>      
                        <a href="<?php echo e(Route('receipts')); ?>" class="btn btn-danger">Ir a Recibos</a>                
                </div>
            </div>
        </div>
        <div class="col-6">
            <h4> Clientes con Saldo Deudor</h4>
            <table class="table table-bordered text-center">
                <thead class="bg-danger">
                    <th>Cliente</th>
                    <th>Saldo Deudor</th>
                    <th>Acciones</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($client->name); ?></td>
                            <td><?php echo e($client->balance); ?></td>
                            <td>
                                <a href="<?php echo e(Route('showClient', $client->id)); ?>" class="btn btn-info">Ver</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\franc\OneDrive\Escritorio\transportes_ruta\resources\views/dashboard.blade.php ENDPATH**/ ?>